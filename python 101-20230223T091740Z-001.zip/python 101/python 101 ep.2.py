Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
name='Arunee'
name='Arunee'
type(name)
<class 'str'>
name.lower()
'arunee'
name.upper()
'ARUNEE'
name.count()
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    name.count()
TypeError: count() takes at least 1 argument (0 given)
>>> name.format()
'Arunee'
>>> friend='สมชาย'
>>> print('สวัสดีสมชาย สบายดีไหม')
สวัสดีสมชาย สบายดีไหม
>>> print('สวัสดี'+friend+'สบายดีมั้ย?')
สวัสดีสมชายสบายดีมั้ย?
>>> money=10
>>> print(friend+'ยืมเงิน'+money+'บาท')
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    print(friend+'ยืมเงิน'+money+'บาท')
TypeError: can only concatenate str (not "int") to str
>>> type(money)
<class 'int'>
>>> print(friend+'ยืมเงิน'+str(money)+'บาท')
สมชายยืมเงิน10บาท
>>> print('{}ยืมเงิน 10 {} บาท'.format(friend,money))
สมชายยืมเงิน 10 10 บาท
>>> print('{}ยืมเงิน{} บาท'.format(friend,money))
สมชายยืมเงิน10 บาท
>>> print(f'{frined}ยืมเงิน{money}บาท')
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    print(f'{frined}ยืมเงิน{money}บาท')
NameError: name 'frined' is not defined. Did you mean: 'friend'?
>>> print(f'{friend}ยืมเงิน {money} บาท')
สมชายยืมเงิน 10 บาท
>>> money=1454541111534
>>> print(f'{money:,}}
...       
SyntaxError: incomplete input
>>> print(f'{money:,}')
...       
1,454,541,111,534
>>> print(f'{money:,.2f}')
...       
1,454,541,111,534.00
