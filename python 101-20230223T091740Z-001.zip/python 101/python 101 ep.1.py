print('Hello Word')
print('Hello Word')
print('Hello Word')

