from tkinter import *
from tkinter import ttk
from tkinter import messagebox

GUI=Tk()
GUI.title('ข้อมูลการรับทุนปัจจัยพื้นฐานของนักเรียนชั้น ม.1/8')
GUI.geometry('700x500')

L1=Label(GUI,text='รายละเอียดข้อมูลนักเรียนที่ได้รับทุนปัจจัยพื้นฐาน',font=('AansaneNew',20),fg='blue')
L1.place(x=40,y=30)
         
##################################
def Button2():
    text='เงินทุนปัจจัยพื้นฐาน รายละ 1,500 บาท'
    messagebox.showinfo('จำนวน 5 ราย ดังนี้',text)
FB1=Frame(GUI)
FB1.place(x=300,y=100)
B2=ttk.Button(FB1,text='จำนวนเงิน',command=Button2)
B2.pack(ipadx=20,ipady=20)
###################################

def Button3():
    text='ณ โดมอเนกประสงค์ หน้าอาคาร 1 '
    messagebox.showinfo('วันที่ 24 กุมภาพันธ์ 2566',text)
FB2=Frame(GUI)
FB2.place(x=200,y=150)
B3=ttk.Button(FB1,text='วันที่รับเงิน',command=Button3)
B3.pack(ipadx=20,ipady=20)
##################################################
def Button4():
    text='ด.ญ.ณธิดา,ด.ช.ชยานันต์,ด.ญ.วนิดา,ด.ช.ชยธร,ด.ช.กวิน'
    messagebox.showinfo('จำนวน 5 ราย',text)
FB3=Frame(GUI)
FB3.place(x=300,y=250)
B4=ttk.Button(FB1,text='รายชื่อผู้รับทุน',command=Button4)
B4.pack(ipadx=20,ipady=20)
#########################################
def Button5():
    text='ผู้ปกครองนำบัตรประจำตัวประชาชนมาแสดงเพื่อรับเงินทุนด้วยตนเอง'
    messagebox.showinfo('เอกสารที่จำเป็น',text)
FB4=Frame(GUI)
FB4.place(x=400,y=300)
B5=ttk.Button(FB1,text='เอกสารที่ใช้',command=Button5)
B5.pack(ipadx=20,ipady=20)



GUI.mainloop()
