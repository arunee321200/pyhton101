import info
import study
from mone import
print(info.name)
